package com.macat.waystonemap;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class WaystoneHintEvents {
    private static final String WAYSTONES_NS = "waystones";
    private static final class_2561 HINT = class_2561.method_43470("You can also teleport via the world map by right-clicking Waystone waypoints.");
    private static final Map<UUID, Long> LAST_HINT = new HashMap<>();
    private static final long COOLDOWN_MS = 5000L;

    private static boolean shouldShowHint(class_1657 player) {
        long now = System.currentTimeMillis();
        UUID id = player.method_5667();
        Long last = LAST_HINT.get(id);
        if (last != null && now - last < COOLDOWN_MS) return false;
        LAST_HINT.put(id, now);
        return true;
    }

    public static void maybeShowWaystoneBlockHint(class_1657 player, class_1937 level, class_2680 state) {
        if (player == null || level == null || player.method_5715()) return;
        class_2960 rl = class_7923.field_41175.method_10221(state.method_26204());
        if (rl != null && WAYSTONES_NS.equals(rl.method_12836()) && rl.method_12832().contains("waystone") && shouldShowHint(player)) {
            player.method_7353(HINT, true);
        }
    }

    public static void maybeShowWaystoneItemHint(class_1657 player, class_1268 hand) {
        if (player == null || hand != class_1268.field_5808) return;
        class_1799 stack = player.method_5998(hand);
        class_2960 rl = class_7923.field_41178.method_10221(stack.method_7909());
        if (rl != null && WAYSTONES_NS.equals(rl.method_12836()) && (rl.method_12832().contains("warp_stone") || rl.method_12832().contains("warp_scroll")) && shouldShowHint(player)) {
            player.method_7353(HINT, true);
        }
    }
}
