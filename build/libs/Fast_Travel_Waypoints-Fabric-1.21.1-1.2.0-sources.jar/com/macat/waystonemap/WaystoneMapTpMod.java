package com.macat.waystonemap;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2277;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class WaystoneMapTpMod implements ModInitializer {


    private static final int COUNTDOWN_SECONDS = 3;
    private static final int TICKS_PER_SECOND = 20;
    private static final Map<UUID, PendingTeleport> PENDING = new ConcurrentHashMap<>();
    private static final Map<UUID, PostTeleportFx> POST_FX = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        ModConfigs.register();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerCommands(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
        UseBlockCallback.EVENT.register(this::onUseBlock);
        UseItemCallback.EVENT.register((player, world, hand) -> {
            WaystoneHintEvents.maybeShowWaystoneItemHint(player, hand);
            return net.minecraft.class_1271.method_22430(player.method_5998(hand));
        });
    }
    public net.minecraft.class_1269 onUseBlock(class_1657 player, class_1937 level, net.minecraft.class_1268 hand, net.minecraft.class_3965 hitResult) {
        if (hand != net.minecraft.class_1268.field_5808) return net.minecraft.class_1269.field_5811;
        class_2338 pos = hitResult.method_17777();
        if (!ModConfigs.REPLACE_WAYSTONE_SCREEN_WITH_WORLD_MAP.get()) {
            WaystoneHintEvents.maybeShowWaystoneBlockHint(player, level, level.method_8320(pos));
            return net.minecraft.class_1269.field_5811;
        }
        
        if (player.method_5715()) return net.minecraft.class_1269.field_5811;

        
        if (!isWaystoneBlock(level, pos)) return net.minecraft.class_1269.field_5811;

        if (isLikelyBoundScroll(player.method_6047())) return net.minecraft.class_1269.field_5811;
        if (!isWaystoneActivatedForPlayer(player, level, pos)) {
            WaystoneHintEvents.maybeShowWaystoneBlockHint(player, level, level.method_8320(pos));
            return net.minecraft.class_1269.field_5811;
        }

        if (level.field_9236) {
            level.method_8396(player, pos, class_7923.field_41172.method_10223(class_2960.method_60654("minecraft:block.end_portal_frame.fill")), class_3419.field_15245, 0.85f, 1.0f);
            invokeClientHook("tryOpenXaeroWorldMap");
        }
        return net.minecraft.class_1269.field_5812;
    }
    public void registerCommands(CommandDispatcher<class_2168> dispatcher) {

        dispatcher.register(
            class_2170.method_9247("wstp")
                .requires(source -> source.method_9228() instanceof class_3222)
                .then(class_2170.method_9244("pos", class_2277.method_9737())
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        if (!(source.method_9228() instanceof class_3222 player)) {
                            source.method_9213(class_2561.method_43470("This command can only be used by players."));
                            return 0;
                        }

                        class_243 vec = class_2277.method_9736(ctx, "pos");
                        class_2338 targetPos = class_2338.method_49637(vec.field_1352, vec.field_1351, vec.field_1350);
                        class_3218 level = source.method_9225();

                        return handleTeleport(player, level, targetPos, vec, null);
                    })
                    .then(class_2170.method_9244("name", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            class_2168 source = ctx.getSource();
                            if (!(source.method_9228() instanceof class_3222 player)) {
                                source.method_9213(class_2561.method_43470("This command can only be used by players."));
                                return 0;
                            }

                            class_243 vec = class_2277.method_9736(ctx, "pos");
                            class_2338 targetPos = class_2338.method_49637(vec.field_1352, vec.field_1351, vec.field_1350);
                            class_3218 level = source.method_9225();
                            String name = StringArgumentType.getString(ctx, "name");

                            return handleTeleport(player, level, targetPos, vec, name);
                        })
                    )
                )
        );
    }

    private boolean canStartFastTravel(class_3222 player, class_3218 level) {
        // Creative always bypasses restrictions (and also bypasses the countdown).
        if (player.field_13974.method_14257() == class_1934.field_9220 || player.field_13974.method_14257() == class_1934.field_9219) return true;

        if (ModConfigs.REQUIRE_NEARBY_WAYSTONE_FOR_USE.get()) {
            int radius = ModConfigs.NEARBY_WAYSTONE_USE_RADIUS.get();
            if (!isPlayerNearAnyWaystone(level, player.method_24515(), radius)) {
                player.method_7353(
                        class_2561.method_43470("You must be within " + radius + " blocks of a Waystone to fast travel.").method_27692(class_124.field_1061),
                        true
                );
                return false;
            }
        }

        // Open sky requirement (ignores leaves + transparent blocks like glass). Checked from the player's upper body (1 block above feet).
        if (ModConfigs.requireOpenSkyPlayer() && isOpenSkyCheckEnabledInThisDimension(level)) {
            class_2338 pos = player.method_24515().method_10084();
            if (!canSeeSkyIgnoringLeaves(level, pos)) {
                player.method_7353(
                        class_2561.method_43470("Fast travel requires open sky.").method_27692(class_124.field_1061),
                        true
                );
                return false;
            }
        }

        // Min Y requirement
        if (ModConfigs.ENABLE_MIN_Y_CHECK.get()) {
            int minY = ModConfigs.MIN_Y.get();
            if (player.method_23318() < (double) minY) {
                player.method_7353(
                        class_2561.method_43470("Fast travel requires Y ≥ " + minY + ".").method_27692(class_124.field_1061),
                        true
                );
                return false;
            }
        }

        // Level cost requirement
        int cost = ModConfigs.LEVEL_COST.get();
        if (cost > 0 && player.field_7520 < cost) {
            player.method_43496(
                    class_2561.method_43470("Fast travel requires " + cost + " " + (cost == 1 ? "level" : "levels") + ".").method_27692(class_124.field_1061)
            );
            return false;
        }

        return true;
    }

    private boolean canSeeSkyIgnoringLeaves(class_3218 level, class_2338 pos) {
        // "Open sky" check that:
        // - ignores leaves
        // - ignores ALL fluids (water, lava, modded fluids)
        // - allows transparent skylight-propagating blocks like glass
        //
        // We treat the sky as "visible" if there is no block above that *stops skylight propagation*.
        // This matches the intuitive "outdoor" feel and still blocks under solid ceilings (including slabs/stairs),
        // while allowing glass roofs.
        int maxY = level.method_31600() - 1;
        int x = pos.method_10263();
        int z = pos.method_10260();

        for (int y = pos.method_10264(); y <= maxY; y++) {
            class_2338 p = new class_2338(x, y, z);
            class_2680 state = level.method_8320(p);

            if (state.method_26215()) continue;
            // Treat pure fluids (water/lava/modded) like air, but do NOT ignore waterlogged solid blocks.
            if (!state.method_26227().method_15769() && state.method_26220(level, p).method_1110()) continue;
            if (state.method_26164(net.minecraft.class_3481.field_15503)) continue;

            // If skylight can't propagate through this block, it's not "open sky".
            if (!state.method_26167(level, p)) {
                return false;
            }
        }
        return true;
    }

    private boolean isPlayerNearAnyWaystone(class_3218 level, class_2338 playerPos, int radius) {
        int minY = Math.max(level.method_31607(), playerPos.method_10264() - Math.min(radius, 4));
        int maxY = Math.min(level.method_31600() - 1, playerPos.method_10264() + Math.min(radius, 4));
        int radiusSq = radius * radius;

        for (int y = minY; y <= maxY; y++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if ((dx * dx) + (dz * dz) > radiusSq) continue;

                    class_2338 checkPos = new class_2338(playerPos.method_10263() + dx, y, playerPos.method_10260() + dz);
                    if (!isWaystoneBlock(level, checkPos)) continue;

                    class_2338 bottom = checkPos;
                    while (isWaystoneBlock(level, bottom.method_10074())) {
                        bottom = bottom.method_10074();
                    }

                    class_243 playerCenter = new class_243(playerPos.method_10263() + 0.5D, playerPos.method_10264() + 0.5D, playerPos.method_10260() + 0.5D);
                    class_243 waystoneCenter = new class_243(bottom.method_10263() + 0.5D, bottom.method_10264() + 0.5D, bottom.method_10260() + 0.5D);
                    if (playerCenter.method_1025(waystoneCenter) <= radiusSq) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private boolean isOpenSkyCheckEnabledInThisDimension(class_3218 level) {
        // Only enforce open-sky in whitelisted dimensions (defaults: overworld + the_end).
        // If the whitelist is empty, treat it as "disabled everywhere".
        var list = ModConfigs.OPEN_SKY_DIMENSION_WHITELIST.get();
        if (list == null || list.isEmpty()) return false;

        class_2960 dim = level.method_27983().method_29177();
        for (String s : list) {
            if (s == null || s.isBlank()) continue;
            class_2960 rl = class_2960.method_12829(s);
            if (rl != null && rl.equals(dim)) return true;
        }
        return false;
    }

private int handleTeleport(class_3222 player, class_3218 level, class_2338 targetPos, class_243 exactPos, String waypointName) {
        Optional<class_2338> waystoneBottom = findWaystoneBottom(level, targetPos);

        // If it's a waystone waypoint, ALWAYS use safe-teleport (even for OPs).
        if (waystoneBottom.isPresent()) {
            if (!canStartFastTravel(player, level)) {
            return 0;
        }
        startWaystoneTeleportCountdown(player, level, waystoneBottom.get(), exactPos, waypointName);
            return 1;
        }

        // Not a waystone: non-OPs get denied, OPs can teleport anywhere.
        if (!player.method_5687(2)) {
            player.method_7353(class_2561.method_43470("No Waystone at the selected waypoint."), true);
            return 0;
        }

        teleportPlayer(player, level, exactPos);
        return 1;
    }

    private void teleportPlayer(class_3222 player, class_3218 level, class_243 exactPos) {
        double x = exactPos.field_1352;
        double y = exactPos.field_1351;
        double z = exactPos.field_1350;
        float yaw = player.method_36454();
        float pitch = player.method_36455();
        player.method_14251(level, x, y, z, yaw, pitch);
    }

    private void safeTeleportToWaystoneNow(class_3222 player, class_3218 level, class_2338 waystoneBottom, class_243 fallbackExact) {
        Optional<class_243> safe = findSafeTeleportPos(level, waystoneBottom);
        if (safe.isPresent()) {
            teleportPlayer(player, level, safe.get());
            return;
        }

        // Never force-teleport into blocks (even for OPs). If no safe spot exists, fail with a clear message.
        player.method_7353(class_2561.method_43470("No empty space next to that waystone.")
                .method_27692(net.minecraft.class_124.field_1061), true);
    }

    private void startWaystoneTeleportCountdown(class_3222 player, class_3218 level, class_2338 waystoneBottom, class_243 fallbackExact, String waypointName) {
        // If the required client-side mods are missing, don't start a countdown
        // (but still allow the server-side teleport logic to run, so the mod remains usable).
        // The hard dependency is enforced via mods.toml on the client.

        String displayName = chooseDisplayName(level, waystoneBottom, waypointName);

        Optional<class_243> safeNow = findSafeTeleportPos(level, waystoneBottom);
        if (safeNow.isEmpty()) {
            player.method_7353(class_2561.method_43470("No empty space next to that waystone.")
                    .method_27692(class_124.field_1061), true);
            return;
        }


        // Destination open-sky requirement (optional). Uses the computed safe landing spot as the origin (+1 block).
        if (!(player.field_13974.method_14257() == class_1934.field_9220 || player.field_13974.method_14257() == class_1934.field_9219)) {
        if (ModConfigs.REQUIRE_OPEN_SKY_DESTINATION.get() && isOpenSkyCheckEnabledInThisDimension(level)) {
            class_2338 destCheck = class_2338.method_49638(safeNow.get()).method_10084();
            if (!canSeeSkyIgnoringLeaves(level, destCheck)) {
                player.method_7353(class_2561.method_43470("Fast travel destination requires open sky.")
                        .method_27692(class_124.field_1061), true);
                return;
            }
        }
        }


        // Creative mode should skip the whole countdown: instant teleport.
        if (player.field_13974.method_14257() == class_1934.field_9220) {
            // Small poof at the origin.
            class_3218 pl = player.method_51469();
            pl.method_14199(class_2398.field_11203,
                    player.method_23317(), player.method_23318() + 0.2D, player.method_23321(),
                    18, 0.35D, 0.2D, 0.35D, 0.01D);

            // We already validated there is a safe spot; use it.
            teleportPlayer(player, level, safeNow.get());
            // After arriving, do portal particles + teleport sound a couple ticks later.
            POST_FX.put(player.method_5667(), new PostTeleportFx(4));
            return;
        }

        PendingTeleport pending = new PendingTeleport(level.method_27983().method_29177().toString(), waystoneBottom, fallbackExact, displayName);
        PENDING.put(player.method_5667(), pending);

        // Immediate first title/sound (3s)
        sendCountdownTitle(player, displayName, COUNTDOWN_SECONDS);
        playSoftNote(player);
    }
    public void onServerTick(MinecraftServer server) {

        for (Map.Entry<UUID, PendingTeleport> e : PENDING.entrySet()) {
            UUID id = e.getKey();
            PendingTeleport p = e.getValue();

            class_3222 player = server.method_3760().method_14602(id);
            if (player == null) {
                PENDING.remove(id);
                continue;
            }

            p.ticksRemaining--;

            // Portal particles during countdown so others can see you're about to teleport.
            // Keep it light to avoid spam.
            if (p.ticksRemaining > 0 && (p.ticksRemaining % 4 == 0)) {
                class_3218 pl = player.method_51469();
                pl.method_14199(class_2398.field_11214,
                        player.method_23317(), player.method_23318() + 0.8D, player.method_23321(),
                        6, 0.45D, 0.7D, 0.45D, 0.02D);
            }

            // Titles at 2s and 1s
            if (p.ticksRemaining == 2 * TICKS_PER_SECOND) {
                sendCountdownTitle(player, p.waystoneName, 2);
                playSoftNote(player);
                // Darkness should start around here and run its course (no forced clear).
                player.method_6092(new class_1293(class_1294.field_38092, 60, 0, false, false, true));
            } else if (p.ticksRemaining == 1 * TICKS_PER_SECOND) {
                sendCountdownTitle(player, p.waystoneName, 1);
                playSoftNote(player);
            }

            // Poof particles shortly before teleport
            if (p.ticksRemaining == 2) {
                class_3218 pl = player.method_51469();
                pl.method_14199(class_2398.field_11203,
                        player.method_23317(), player.method_23318() + 0.2D, player.method_23321(),
                        18, 0.35D, 0.2D, 0.35D, 0.01D);
            }

            if (p.ticksRemaining <= 0) {
                PENDING.remove(id);

                class_3218 level = server.method_3847(player.method_37908().method_27983());
                if (level == null) level = player.method_51469();

                // Consume XP levels right before teleport (if configured).
                int cost = ModConfigs.LEVEL_COST.get();
                if (cost > 0 && player.field_13974.method_14257() != class_1934.field_9220) {
                    if (player.field_7520 < cost) {
                        player.method_7353(
                                class_2561.method_43470("Fast travel requires " + cost + " " + (cost == 1 ? "level" : "levels") + ".").method_27692(class_124.field_1061),
                                true
                        );
                        continue;
                    }
                    player.method_7316(-cost);
                }

                safeTeleportToWaystoneNow(player, level, p.waystoneBottom, p.fallbackExact);

                // Post-teleport effects should happen at the ARRIVAL position.
                // Delay a few ticks so the client is fully at the new spot.
                POST_FX.put(player.method_5667(), new PostTeleportFx(4));
            }
        }

        // Run delayed post-teleport effects.
        for (Map.Entry<UUID, PostTeleportFx> e : POST_FX.entrySet()) {
            UUID id = e.getKey();
            PostTeleportFx fx = e.getValue();
            class_3222 player = server.method_3760().method_14602(id);
            if (player == null) {
                POST_FX.remove(id);
                continue;
            }
            fx.ticks--;
            if (fx.ticks <= 0) {
                POST_FX.remove(id);

                // Ender-pearl-like teleport sound (played at arrival).
                playTeleportSoundAtArrival(player);

                // Portal particles after arriving.
                class_3218 arr = player.method_51469();
                arr.method_14199(class_2398.field_11214,
                        player.method_23317(), player.method_23318() + 0.8D, player.method_23321(),
                        24, 0.55D, 0.8D, 0.55D, 0.05D);
            }
        }
    }

    private void sendCountdownTitle(class_3222 player, String waystoneName, int seconds) {
        class_2561 title = class_2561.method_43470(waystoneName).method_27692(class_124.field_1054);
        class_2561 subtitle = class_2561.method_43470("Teleporting in " + seconds + "s").method_27692(class_124.field_1068);

        // 0 fade-in, short stay, soft fade-out. Each second replaces previous.
        player.field_13987.method_14364(new net.minecraft.class_5905(0, 18, 10));
        player.field_13987.method_14364(new net.minecraft.class_5904(title));
        player.field_13987.method_14364(new net.minecraft.class_5903(subtitle));
    }

    private void playSoftNote(class_3222 player) {
        // Prefer a newer note block instrument sound if present; fall back to pling.
        class_3414 se = class_7923.field_41172.method_10223(class_2960.method_60654("block.note_block.chime"));
        if (se == null) se = class_7923.field_41172.method_10223(class_2960.method_60654("block.note_block.bell"));
        if (se == null) se = class_7923.field_41172.method_10223(class_2960.method_60654("block.note_block.pling"));
        if (se != null) {
            player.method_17356(se, class_3419.field_15248, 0.6f, 1.2f);
        }
    }

    private void playTeleportSoundAtArrival(class_3222 player) {
        class_3414 se = class_7923.field_41172.method_10223(class_2960.method_60654("entity.enderman.teleport"));
        if (se != null) {
            player.method_51469().method_8396(null, player.method_24515(), se, class_3419.field_15248, 0.9f, 1.0f);
        }
    }

    private String chooseDisplayName(class_3218 level, class_2338 waystoneBottom, String waypointName) {
        if (waypointName != null) {
            String cleaned = waypointName.trim();
            if (!cleaned.isBlank() && !"{name}".equals(cleaned)) {
                if ((cleaned.startsWith("\"") && cleaned.endsWith("\"")) || (cleaned.startsWith("'") && cleaned.endsWith("'"))) {
                    cleaned = cleaned.substring(1, cleaned.length() - 1).trim();
                }
                if (!cleaned.isBlank()) return cleaned;
            }
        }
        return getWaystoneNameSafe(level, waystoneBottom);
    }

    private String getWaystoneNameSafe(class_3218 level, class_2338 waystoneBottom) {
        // Default if we can't extract a custom name.
        String fallback = "Waystone";

        try {
            class_2586 be = level.method_8321(waystoneBottom);
            if (be == null) be = level.method_8321(waystoneBottom.method_10084());
            if (be == null) return fallback;

            // Common patterns across Waystones versions (try a few via reflection)
            for (String mName : new String[]{"getName", "getDisplayName", "getWaystoneName", "getCustomName"}) {
                Method m = be.getClass().getMethod(mName);
                Object r = m.invoke(be);
                if (r instanceof class_2561 c) {
                    String s = c.getString();
                    if (s != null && !s.isBlank()) return s;
                }
                if (r instanceof String s) {
                    if (!s.isBlank()) return s;
                }
            }
        } catch (Throwable ignored) {
        }

        return fallback;
    }

    private void invokeClientHook(String methodName) {
        try {
            Class<?> clientHooksClass = Class.forName("com.macat.waystonemap.ClientHooks");
            clientHooksClass.getMethod(methodName).invoke(null);
        } catch (Throwable ignored) {
        }
    }

    private boolean isLikelyBoundScroll(net.minecraft.class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_2960 rl = class_7923.field_41178.method_10221(stack.method_7909());
        if (rl == null) return false;
        return "waystones".equals(rl.method_12836()) && rl.method_12832().contains("bound_scroll");
    }

    private boolean isWaystoneActivatedForPlayer(class_1657 player, class_1937 level, class_2338 pos) {
        try {
            class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity == null && isWaystoneBlock(level, pos.method_10074())) {
                blockEntity = level.method_8321(pos.method_10074());
            }
            if (blockEntity == null) return false;

            Method getWaystone = blockEntity.getClass().getMethod("getWaystone");
            Object waystone = getWaystone.invoke(blockEntity);
            if (waystone == null) return false;

            // Prefer the stable public API first.
            try {
                Class<?> apiClass = Class.forName("net.blay09.mods.waystones.api.WaystonesAPI");
                for (Method method : apiClass.getMethods()) {
                    if (!method.getName().equals("isWaystoneActivated")) continue;
                    Class<?>[] params = method.getParameterTypes();
                    if (params.length == 2 && params[0].isAssignableFrom(player.getClass()) && params[1].isInstance(waystone)) {
                        Object result = method.invoke(null, player, waystone);
                        if (result instanceof Boolean b) return b;
                    }
                }
            } catch (Throwable ignored) {
            }

            Class<?> managerClass = Class.forName("net.blay09.mods.waystones.core.PlayerWaystoneManager");
            for (Method method : managerClass.getMethods()) {
                if (!method.getName().equals("isWaystoneActivated")) continue;
                Class<?>[] params = method.getParameterTypes();
                if (params.length == 2 && params[0].isAssignableFrom(player.getClass()) && params[1].isInstance(waystone)) {
                    Object result = method.invoke(null, player, waystone);
                    if (result instanceof Boolean b) return b;
                }
            }
        } catch (Throwable ignored) {
        }

        return false;
    }

    private static class PendingTeleport {
        final String dim;
        final class_2338 waystoneBottom;
        final class_243 fallbackExact;
        final String waystoneName;
        int ticksRemaining;

        PendingTeleport(String dim, class_2338 waystoneBottom, class_243 fallbackExact, String waystoneName) {
            this.dim = dim;
            this.waystoneBottom = waystoneBottom;
            this.fallbackExact = fallbackExact;
            this.waystoneName = waystoneName;
            this.ticksRemaining = COUNTDOWN_SECONDS * TICKS_PER_SECOND;
        }
    }

    private static class PostTeleportFx {
        int ticks;
        PostTeleportFx(int ticks) { this.ticks = ticks; }
    }

    /**
     * Checks around the target position for a Waystone block.
     * We search a 3x3 area in X/Z (radius 1) and a small vertical range
     * from Y-2 to Y+1 to account for player height and fractional coords.
     */
    /**
     * Finds a waystone block near the waypoint and returns the BOTTOM blockpos of the 2-block waystone.
     */
    private Optional<class_2338> findWaystoneBottom(class_1937 level, class_2338 targetPos) {
        int radiusXZ = 1;
        int baseY = targetPos.method_10264();

        for (int dy = -2; dy <= 2; dy++) {
            int y = baseY + dy;
            for (int dx = -radiusXZ; dx <= radiusXZ; dx++) {
                for (int dz = -radiusXZ; dz <= radiusXZ; dz++) {
                    class_2338 checkPos = new class_2338(targetPos.method_10263() + dx, y, targetPos.method_10260() + dz);
                    if (isWaystoneBlock(level, checkPos)) {
                        // Walk down to bottom of the 2-block waystone
                        class_2338 bottom = checkPos;
                        while (isWaystoneBlock(level, bottom.method_10074())) {
                            bottom = bottom.method_10074();
                        }
                        return Optional.of(bottom);
                    }
                }
            }
        }

        // Also handle the common case where the waypoint is on the TOP block.
        if (isWaystoneBlock(level, targetPos.method_10074())) {
            class_2338 bottom = targetPos.method_10074();
            while (isWaystoneBlock(level, bottom.method_10074())) {
                bottom = bottom.method_10074();
            }
            return Optional.of(bottom);
        }

        return Optional.empty();
    }

    private boolean isWaystoneBlock(class_1937 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        if (state.method_26215()) return false;
        class_2960 rl = class_7923.field_41175.method_10221(state.method_26204());
        if (rl == null) return false;
        return "waystones".equals(rl.method_12836()) && rl.method_12832().contains("waystone");
    }

    private static final class_2350[] SIDE_ORDER = new class_2350[]{
            class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039
    };

    /**
     * Preferred behavior:
     *  1) Try adjacent spots at waystone level (needs 2 blocks free + standable floor)
     *  2) Try standing on top of a 1-block-high neighbor (feet at adjacent+1)
     *  3) Try above the waystone (feet at bottom+2)
     *  4) If no floor exists at that level, try 1-2 blocks lower (still 2 blocks free + floor)
     *  5) Fallback: allow spots with 2 blocks free even without a floor (prevents "false no space")
     */
    private Optional<class_243> findSafeTeleportPos(class_3218 level, class_2338 waystoneBottom) {
        // 1) Same level with floor
        Optional<class_243> same = findAdjacent(level, waystoneBottom, true, new int[]{0});
        if (same.isPresent()) return same;

        // 2) On top of a 1-block-high neighbor (lets players stand on a block next to the waystone)
        Optional<class_243> atopNeighbor = findAdjacentTop(level, waystoneBottom);
        if (atopNeighbor.isPresent()) return atopNeighbor;

        // 3) Above waystone (two blocks above bottom, because waystone is 2 tall)
        // Prefer this BEFORE placing players next to floorless drop-offs.
        class_2338 aboveFeet = waystoneBottom.method_10086(2);
        if (isTwoTallFree(level, aboveFeet, true)) {
            return Optional.of(centerFeet(aboveFeet));
        }

        // 4) Lower levels with floor (up to 2 blocks down)
        Optional<class_243> lower = findAdjacent(level, waystoneBottom, true, new int[]{-1, -2});
        if (lower.isPresent()) return lower;

        // 5) Fallback without floor requirement (same -> lower -> above)
        Optional<class_243> sameNoFloor = findAdjacent(level, waystoneBottom, false, new int[]{0, -1, -2});
        if (sameNoFloor.isPresent()) return sameNoFloor;

        if (isTwoTallFree(level, aboveFeet, false)) {
            return Optional.of(centerFeet(aboveFeet));
        }

        return Optional.empty();
    }

    /**
     * Allows teleporting onto a single block adjacent to the waystone, e.g. if there's a 1-block step.
     * Example: if the block next to the waystone is solid, we can place the player on top of it.
     */
    private Optional<class_243> findAdjacentTop(class_3218 level, class_2338 waystoneBottom) {
        for (class_2350 dir : SIDE_ORDER) {
            class_2338 neighbor = waystoneBottom.method_10093(dir);
            class_2338 feet = neighbor.method_10084();
            // Require a floor (the neighbor block) and 2 blocks of headroom at the feet position.
            if (isTwoTallFree(level, feet, true)) {
                return Optional.of(centerFeet(feet));
            }
        }
        return Optional.empty();
    }

    private Optional<class_243> findAdjacent(class_3218 level, class_2338 waystoneBottom, boolean requireFloor, int[] yOffsets) {
        for (int yOff : yOffsets) {
            for (class_2350 dir : SIDE_ORDER) {
                class_2338 feet = waystoneBottom.method_10093(dir).method_10069(0, yOff, 0);
                if (isTwoTallFree(level, feet, requireFloor)) {
                    return Optional.of(centerFeet(feet));
                }
            }
        }
        return Optional.empty();
    }

    private boolean isTwoTallFree(class_3218 level, class_2338 feet, boolean requireFloor) {
        if (!isNonColliding(level, feet)) return false;
        if (!isNonColliding(level, feet.method_10084())) return false;

        if (requireFloor) {
            class_2338 floorPos = feet.method_10074();
            class_2680 floor = level.method_8320(floorPos);
            // Waystone tops may not report as "sturdy" even though you can stand on them.
            // Allow standing on the waystone itself (used for the "above waystone" case).
            if (!floor.method_26206(level, floorPos, class_2350.field_11036) && !isWaystoneBlock(level, floorPos)) return false;
        }

        return true;
    }

    private boolean isNonColliding(class_3218 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        return state.method_26220(level, pos).method_1110();
    }

    private class_243 centerFeet(class_2338 feet) {
        return new class_243(feet.method_10263() + 0.5D, feet.method_10264(), feet.method_10260() + 0.5D);
    }

    private Double parseCoord(String s) {
        try {
            // Xaero uses absolute numbers here, but be permissive with decimals.
            return Double.parseDouble(s);
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

}
